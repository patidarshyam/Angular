import { Component,OnInit } from '@angular/core';

@Component({
  selector: 'app-sidenav',
  templateUrl: './sidenav.component.html',
  styleUrls: ['./sidenav.component.scss']
})
export class SidenavComponent  {
  isOpen = false;
 
  selectedItem: any;
  
  constructor() {
  }
  toggle(){
  	this.isOpen = !this.isOpen;
  }

  activeItem(event, name){
    this.selectedItem = name;
  }

}
