import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { HeaderComponent } from './header/header.component';
import { FooterComponent } from './footer/footer.component';
import { SidenavComponent } from './sidenav/sidenav.component';
import { AppLoaderComponent } from './app-loader/app-loader.component';
import { ToolbarComponent } from './Navigation/toolbar/toolbar.component';
import { MatSidenavModule } from '@angular/material/sidenav';
import { MatToolbarModule } from '@angular/material/toolbar';
import { MatTabsModule } from '@angular/material/tabs';
import { MatListModule } from '@angular/material/list';
import {MatIconModule} from '@angular/material/icon';
import { SidenavListComponent } from './Navigation/sidenav-list/sidenav-list.component';

@NgModule({
  declarations: [
    HeaderComponent,
    FooterComponent,
    SidenavComponent,
    AppLoaderComponent,
    ToolbarComponent,
    SidenavListComponent
  ],
  imports: [
    CommonModule,
    MatSidenavModule,
    MatToolbarModule,
    MatTabsModule,
    MatListModule,
    MatIconModule   
       
  ], 
  exports:[
    HeaderComponent,
    FooterComponent,
    SidenavComponent,
    MatSidenavModule,
    MatToolbarModule,
    MatTabsModule,
    MatListModule,
    MatIconModule,
    AppLoaderComponent,
    ToolbarComponent,
    SidenavListComponent
    

  ] 
})
export class SharedModule { }
