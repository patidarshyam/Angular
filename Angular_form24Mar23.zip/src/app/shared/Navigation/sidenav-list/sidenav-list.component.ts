import { Component,EventEmitter, OnInit, Output } from '@angular/core';

@Component({
  selector: 'app-sidenav-list',
  templateUrl: './sidenav-list.component.html',
  styleUrls: ['./sidenav-list.component.scss']
})
export class SidenavListComponent implements OnInit {

  Secondary_process_uflifo: string;


  adminLinksFlag = true;
  externalLinksFlag = true;
  dataQualityFlag = true;
  swaggerLinksFlag = true;
  swaggerLinksPrimaryFlag = false;
  swaggerLinksSecondaryFlag = false;
  @Output() closeSideNav = new EventEmitter();
  constructor(){
    this.Secondary_process_uflifo = "";
  }
  onToggleClose() {
    this.closeSideNav.emit();
    }

  ngOnInit() {
    }

}
