export interface FlifoEntityInterface {
    flifoEntity?:string;
    flightDate?:string;
    domain?:string;

}

