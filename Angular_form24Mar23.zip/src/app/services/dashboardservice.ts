import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { Observable } from 'rxjs';
import { Dashboardinterface } from '../services/dashboardinterface';

@Injectable({
  providedIn: 'root'
})
export class DashboardService {
    constructor(private http: HttpClient) { }
   
    // getDashboardData(): Observable<any> {
    //     return this.http.get('assets/data/mockdata.json');
    //   }
      getDashboardData(): Observable<any>  {
        return this.http.get('./assets/data/mockdata.json')
        // .toPromise()
        // .then(res => <Dashboardinterface[]>res.data)
        // .then(data => { return data; });
    }
}