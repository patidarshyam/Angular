import { Injectable } from '@angular/core';
import { HttpClient, HttpHeaders } from '@angular/common/http';
import { Observable } from 'rxjs';

@Injectable({
  providedIn: 'root'
})
export class ManualService {

  constructor(private http: HttpClient) { }

  updateFlightEntity(data: any): Observable<any> {
    const headers = new HttpHeaders({ 'Content-Type': 'application/json'});
    return this.http.get('./assets/data/mockSuccessResponse.json');
    

    //  return this.http.post<any>('https://rte.primary.dev.aws.ual.com/flifoprocessor/searchRawMessage',
    //  data, { headers });
  }
}
