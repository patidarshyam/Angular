export interface Dashboardinterface {
    rank?:number;
    list?:string;
    transaction?:number;
    timeouterror?:number;
    totalerror?:number;
    avgerror?:number;
    inventoryStatus?:number;
    transaction_warned?:number;
    avgWarned?:number;
    totalWarned?:number;
}

