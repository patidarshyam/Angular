import { Component, OnInit } from '@angular/core';
import { FormGroup, FormControl } from '@angular/forms';
import { DashboardService } from '../services/dashboardservice';
import { Dashboardinterface } from '../services/dashboardinterface';
import jsPDF from "jspdf";
import "jspdf-autotable";


@Component({
  selector: 'app-dashboard',
  templateUrl: './dashboard.component.html',
  styleUrls: ['./dashboard.component.scss']
})
export class DashboardComponent implements OnInit {

  dateValue = Date;
  todateValue = Date;
  unitedAir: any[];
  selectedCities2: string[] = [];
  tableData: any[] = [];
  cols: any[] = [];
  dashboardData: Dashboardinterface[] = [];
  exportColumns: any[] = [];
  transaction: any;
  listmultiselect: any;
  area: any
  //userForm: FormGroup;
  constructor(private dashboardservice: DashboardService) {

    // this.userForm = new FormGroup({
    //   area: new FormControl(''),
    //   list: new FormControl(''),
    //   transaction: new FormControl(''),
    //   fromdate: new FormControl(''),
    //   todate: new FormControl('')

    // });

    // this.userForm.setValue({
    //   'userData':{
    //     'area':'UAX',
    //     'list':'ZW',
    //     'transaction':'All',
    //     'fromdate':'1/3/2023',
    //     'todate' : '1/10/2023'
    //   }
    // })

    this.unitedAir = [
      { name: "Air Wisconsin", code: "ZW" },
      { name: "CommuteAir", code: "CS" },
      { name: "ExpressJet", code: "EV" },
      { name: "MesaAirlines", code: "YV" },
      { name: "RepublicAirlines", code: "YX" },
      { name: "SkyWestAirlines", code: "OO" },
      { name: "TranStatesAirlines", code: "AX" }
    ];

  }


  ngOnInit() {

    this.dashboardservice.getDashboardData().subscribe(data => {
      this.dashboardData = data.dashboardData;

      console.log(this.dashboardData);
    });
    this.cols = [
      { field: "sno", header: "" },
      { field: "list", header: "Partners",filter: true },
      { field: "domain", header: "Domain" },
      { field: "eventtotal", header: "Event Total" },
      { field: "eventerror", header: "Event Errored" },
      { field: "totalerror", header: "Total Errors" },
      { field: "avgerror", header: "Avg/Error" },
      { field: "event_warned", header: "Events warned" },
      { field: "totalWarned", header: "Total Warning" },
      { field: "avg/warn", header: "Avg/Warning" },
      { field: "warn_event_per", header: "Warn Events %" },
      { field: "err_event", header: "Error Events%" },
      { field: "balance_score", header: "Balance Score%" },
    ];
    this.exportColumns = this.cols.map(col => ({ title: col.header, dataKey: col.field }));



  }
  //Table Data Export to PDF
  exportPdf() {
    const doc = new jsPDF('p', 'pt');
    doc['autoTable'](this.exportColumns, this.dashboardData);
    doc.save("dashboardData.pdf");
  }
  //Table Data Export to Excel
  exportExcel() {
    import("xlsx").then(xlsx => {
      const worksheet = xlsx.utils.json_to_sheet(this.dashboardData);
      const workbook = { Sheets: { data: worksheet }, SheetNames: ["data"] };
      const excelBuffer: any = xlsx.write(workbook, {
        bookType: "xlsx",
        type: "array"
      });
      this.saveAsExcelFile(excelBuffer, "Dashboardinterface");
    });
  }

  saveAsExcelFile(buffer: any, fileName: string): void {
    import("file-saver").then(FileSaver => {
      let EXCEL_TYPE =
        "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet;charset=UTF-8";
      let EXCEL_EXTENSION = ".xlsx";
      const data: Blob = new Blob([buffer], {
        type: EXCEL_TYPE
      });
      FileSaver.saveAs(
        data,
        fileName + "_export_" + new Date().getTime() + EXCEL_EXTENSION
      );
    });
  }
 //Get Filter Dashboard data
  onSubmit(userForm) {
    console.log(userForm.value);
  }


}


