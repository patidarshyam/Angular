import { AfterViewInit, ChangeDetectorRef, Component, OnInit } from '@angular/core';
import { Router, NavigationEnd, NavigationStart, NavigationCancel } from '@angular/router';

@Component({
  selector: 'app-root',
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.scss']
})
export class AppComponent implements OnInit, AfterViewInit {
  currentYear = new Date().getFullYear();
 
  constructor(
    private router: Router,
    private cdref: ChangeDetectorRef,
   
  ) {
    // iconSet singleton
    
  }

  onActivate(event) {
    window.scroll(0, 0);
  }
  ngOnInit() {
  }
  ngAfterViewInit(){}
}
