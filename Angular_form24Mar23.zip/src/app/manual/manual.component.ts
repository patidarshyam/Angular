
import { Component, Inject, OnInit } from '@angular/core';
import { FormBuilder, FormControl, FormGroup, Validators } from '@angular/forms';
import {ManualService} from '../services/manual.service';
import { MatSnackBar, MAT_SNACK_BAR_DATA } from '@angular/material/snack-bar';
//import { MatSnackBarContent } from '@angular/material/snack-bar';
import { delay } from 'rxjs/operators';

@Component({
  selector: 'app-manual',
  templateUrl: './manual.component.html',
  styleUrls: ['./manual.component.scss']
})
export class ManualComponent implements OnInit {
  manualForm!: FormGroup;
  optionsForm!: FormGroup;
  flifoEntity: string = '';
  loading: boolean = false;
 
  domains = [
    { value: 'FLIFO', label: 'FLIFO' },
    { value: 'CREW', label: 'CREW' },
    { value: 'TAKEOFFS', label: 'TAKEOFFS' }
  ];
  
  constructor(private formBuilder: FormBuilder,
     private manualService: ManualService,
     private snackBar: MatSnackBar ){}
  
  ngOnInit(): void {

    this.manualForm = this.formBuilder.group({
      flifoEntity: ['', [Validators.required, validateJson]],
      flightDate: ['', Validators.required],
      domain: ''
    });


    this.optionsForm = this.formBuilder.group({
      selectedOption: ['manual', Validators.required]
    });
  }

  onSubmit(): void {
    console.log('onSubmit manual form: ',this.manualForm.value);
    this.loading = true;
    if (this.manualForm.valid) {
      // do something with the form data
      console.log('valid form: ',this.manualForm.value);
    } else {
      // show error message or do something else
      console.log('error form: ',this.manualForm.value);
    }
    
    this.updateData(this.manualForm.value);
    console.log('updateData called ()...:');
  }

  resetForm(): void {
    this.manualForm.reset();
  }

  updateData(flifoEntity: any) {
    console.log('update Data obj:',flifoEntity);
    this.loading = true;
    this.manualService.updateFlightEntity(flifoEntity)
    // .pipe( delay(5000)).subscribe(
     .subscribe(
      (response: any) => {
        console.log('flifo service data from API:',response);
        console.log('Suceess:',response.responseData.message);
        this.loading = false;
        this.openSuccessSnackbar(response.responseData.message);
      },
      (error: any) => {
        console.log('api err:', error);
        this.loading = false;
        this.openFailureSnackbar();
      }
    );
  }


  openSuccessSnackbar(message) {
   // const message = 'Success!';
    const action = 'Close';
    this.snackBar.open(
      message,
      action,
      { 
        duration: 5000,
        panelClass: ['my-custom-success-class'], //success-snackbar
        verticalPosition: 'top' 
      });
  }

  openFailureSnackbar() {
    this.snackBar.open('Something went wrong!', 'Close', {
      duration: 5000,
      panelClass: ['failure-snackbar']
    });
  }

  
  
}

function validateJson(control: FormControl) {
  try {
    JSON.parse(control.value);
    return null;
  } catch (error) {
    return { invalidJson: true };
  }
}
