package com.yash.otdfweb.controller;

import javax.servlet.http.HttpServletRequest;

import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;

import com.yash.otdfcore.model.User;

@CrossOrigin(origins="http://localhost:4200")
@RestController
@RequestMapping("/users")
public class UserController {
	

	@RequestMapping(value = "/login", method = RequestMethod.POST)
	public User login(@RequestBody User user) {
		String loginname=user.getLoginname();
		String password=user.getPassword();
		if(loginname.equals("shyam") && password.equals("shyam123")){
			user.setRole(2);
			user.setId(1);
			return user;
		} else
			return null;
	}
}
