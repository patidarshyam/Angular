package com.yash.otdfweb.configuration;

import org.springframework.context.annotation.ComponentScan;
import org.springframework.context.annotation.Configuration;
import org.springframework.web.servlet.config.annotation.CorsRegistry;
import org.springframework.web.servlet.config.annotation.EnableWebMvc;
import org.springframework.web.servlet.config.annotation.WebMvcConfigurerAdapter;

@Configuration
@EnableWebMvc
@ComponentScan("com.yash")
public class OTDFConfiguration extends WebMvcConfigurerAdapter {

	@Override
	public void addCorsMappings(CorsRegistry registry) {
		registry.addMapping("/OTDFWeb/**")
			.allowedOrigins("http://localhost:4200")
			.allowedMethods("POST", "PUT", "GET", "OPTIONS", "DELETE")
			.allowedHeaders("x-requested-with")
			.maxAge(3600);
	}
}
