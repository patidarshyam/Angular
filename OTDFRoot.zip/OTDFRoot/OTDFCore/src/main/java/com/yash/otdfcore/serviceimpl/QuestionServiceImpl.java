package com.yash.otdfcore.serviceimpl;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.yash.otdfcore.dao.QuestionDAO;
import com.yash.otdfcore.model.Question;
import com.yash.otdfcore.service.QuestionService;
/**
 * This is the implementation class of QuestionService.
 * 
 * @author shyam.patidar
 *
 */
@Service
public class QuestionServiceImpl implements QuestionService {
	@Autowired
	private QuestionDAO questionDAO;
	/**
	 * This method of service class will list the all Questions
	 * @return {@link List}
	 */
	public List<Question> listAllQuestion() {
		return questionDAO.list();
	}
	/**
	 * This method of service class will list the specific category of Questions
	 * @return {@link List}
	 */
	public List<Question> listAllQuestion(int category) {
		return questionDAO.list(category);
	}
	/**
	 * This method of service will approve or reject the question request.
	 * its will return positive integer if successfully action complete and return 0 if fail.
	 * @param status
	 * @param quetionId
	 * @return {@link Integer}
	 */
	public int changeQuestionStatus(int status, int quetionId) {
		return questionDAO.takeAction(status, quetionId);
	}
	/**
	 * This method of service will send the notification to the appropriate user after his question is approved or rejected by Admin.
	 * its will return true notification sent successfully
	 * @return {@link Boolean}
	 */
	public boolean updateNotification() {
		return false;
	}

}
