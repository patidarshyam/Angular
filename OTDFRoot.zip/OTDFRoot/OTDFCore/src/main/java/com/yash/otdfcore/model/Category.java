package com.yash.otdfcore.model;

import javax.persistence.Column;
import javax.persistence.Embeddable;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;

/**
 * This class will act as data traveler for category and act as a model. Its
 * contains- id and category_type.
 * 
 * @author shyam.patidar
 *
 */
//@Entity
//@Table(name = "category")
public class Category {
	/**
	 * This is the unique id of category
	 */
//	@Id
//	@GeneratedValue(strategy=GenerationType.AUTO)
	private int id;
	/**
	 * This category_type define the questions category type such as -Categorical questions,
	 * -Interval questions
	 */
	//@Column(nullable=false)
	private String category_type;

	public int getId() {
		return id;
	}

	public void setId(int id) {
		this.id = id;
	}

	public String getCategory_type() {
		return category_type;
	}

	public void setCategory_type(String category_type) {
		this.category_type = category_type;
	}

}
