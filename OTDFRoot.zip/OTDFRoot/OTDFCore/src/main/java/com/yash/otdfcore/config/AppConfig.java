package com.yash.otdfcore.config;
import org.springframework.context.annotation.ComponentScan;
import org.springframework.context.annotation.Configuration;
 
@Configuration
@ComponentScan(basePackages = "com.yash.otdfcore")
public class AppConfig {
 
}