package com.yash.otdfcore.model;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.Table;

/**
 * This class will act as data traveler for question and act as a model. It
 * contains- id, category, status and question
 * 
 * @author shyam.patidar
 *
 */
@Entity
@Table(name = "questions")
public class Question {
	/**
	 * This is the unique id of question
	 */
	@Id
	@GeneratedValue(strategy=GenerationType.AUTO)
	private int id;
	/**
	 * This is the category of question of Category type.
	 * 1-Categorical questions,
	 * 2-Interval questions
	 */
	private int category;
	/**
	 * This is the status of question which is approved or rejected
	 * 1:Approved,2:Rejected,3:Pending
	 */
	@Column(nullable=false)
	private int status;
	/**
	 * This is the question asked by general user
	 */
	@Column(nullable=false)
	private String question;
	/**
	 * This is list of users who will post the questions
	 */
	@ManyToOne
	@JoinColumn(name="user_id")
	private User user;
	


	public int getId() {
		return id;
	}

	public void setId(int id) {
		this.id = id;
	}
	

	public int getCategory() {
		return category;
	}

	public void setCategory(int category) {
		this.category = category;
	}

	public User getUser() {
		return user;
	}

	public void setUser(User user) {
		this.user = user;
	}

	public int getStatus() {
		return status;
	}

	public void setStatus(int status) {
		this.status = status;
	}

	public String getQuestion() {
		return question;
	}

	public void setQuestion(String question) {
		this.question = question;
	}

}
