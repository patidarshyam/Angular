package com.yash.otdfcore.daoimpl;

import java.util.List;

import org.hibernate.Query;
import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;

import com.yash.otdfcore.dao.QuestionDAO;
import com.yash.otdfcore.model.Category;
import com.yash.otdfcore.model.Question;

/**
 * This is the implementation class of QuestionDAO.
 * 
 * @author shyam.patidar
 *
 */
@Repository
public class QuestionDAOImpl implements QuestionDAO {

	@Autowired
	SessionFactory sessionFactory;

	public List<Question> list() {
		Session session = sessionFactory.openSession();
		session.beginTransaction();
		Query query = session.createQuery("from Question");
		List<Question> questions=query.list();
		session.getTransaction().commit();
	
		return questions;
	}

	public List<Question> list(int category) {
		Session session = sessionFactory.openSession();
		session.beginTransaction();
		Query query = session.createQuery("from Question where Category=:category");
		query.setParameter("category", category);
		return query.list();
	}

	public int takeAction(int status, int questionId) {
		Session session = sessionFactory.openSession();
		session.beginTransaction();
		String hql = "UPDATE Question set status = :status WHERE id = :id";
		Query query = session.createQuery(hql);
		query.setParameter("status", status);
		query.setParameter("id", questionId);
		int result = query.executeUpdate();
		System.out.println("Rows affected: " + result);
		return result;
	}

	public boolean notification() {
		//TODO
		return false;
	}

}
