package com.yash.otdfcore.model;

import java.util.ArrayList;
import java.util.List;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.ManyToOne;
import javax.persistence.OneToMany;
import javax.persistence.Table;

/**
 * This class will act as data traveler for user and act as a model.
 * Its contains- id, loginname ,password and role of user.
 * @author shyam.patidar
 *
 */
@Entity
@Table(name = "users")
public class User {
	/**
	 * This is the unique id of user
	 */
	@Id
	@GeneratedValue(strategy=GenerationType.AUTO)
	private int id;
	/**
	 * loginname of user
	 */
	@Column(nullable=false)
	private String loginname;
	/**
	 * password of user
	 */
	@Column(nullable=false)
	private String password;
	/**
	 * This is the role of user 1:Admin_User,2:General_User
	 */
	@Column(nullable=false)
	private int role;
	/**
	 * This is the list of questions which is asked by user.
	 */
	@OneToMany(mappedBy="user")
	private List<Question> questions=new ArrayList<Question>();

	public User() {

	}

	public User(int id, String loginname, String password, int role) {
		this.id = id;
		this.loginname = loginname;
		this.password = password;
		this.role = role;
	}
	

	public List<Question> getQuestions() {
		return questions;
	}

	public void setQuestions(List<Question> questions) {
		this.questions = questions;
	}

	public int getId() {
		return id;
	}

	public void setId(int id) {
		this.id = id;
	}

	public String getLoginname() {
		return loginname;
	}

	public void setLoginname(String loginname) {
		this.loginname = loginname;
	}

	public String getPassword() {
		return password;
	}

	public void setPassword(String password) {
		this.password = password;
	}

	public int getRole() {
		return role;
	}

	public void setRole(int role) {
		this.role = role;
	}

}
