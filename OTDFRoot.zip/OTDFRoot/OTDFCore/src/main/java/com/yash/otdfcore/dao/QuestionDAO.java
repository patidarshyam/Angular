package com.yash.otdfcore.dao;
import java.util.List;
import com.yash.otdfcore.model.Category;
import com.yash.otdfcore.model.Question;
/**
 * This interface perform operation related with Question.
 * @author shyam.patidar
 *
 */
public interface QuestionDAO {
	/**
	 * This method will return the list of all the questions.
	 * @return List<Question>
	 */
	public List<Question> list();
	/**
	 * This method will return the list of specific category of questions.
	 * @param category
	 * @return List<Question>
	 */
	public List<Question> list(int category);
	/**
	 * This method will approve or reject the question request.
	 * its will return positive integer if successfully action complete and return 0 if fail.
	 * @param status
	 * @param quetionId
	 * @return {@link Integer}
	 */
	public int takeAction(int status,int quetionId);
	/**
	 * This method will send the notification to the appropriate user after his question is approved or rejected by Admin.
	 * its will return true notification sent successfully
	 * @return {@link Boolean}
	 */
	public boolean notification();
}
