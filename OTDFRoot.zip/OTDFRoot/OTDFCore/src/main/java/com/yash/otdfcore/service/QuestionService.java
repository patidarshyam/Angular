package com.yash.otdfcore.service;

import java.util.List;

import com.yash.otdfcore.model.Category;
import com.yash.otdfcore.model.Question;

/**
 * 
/**
 * This interface provides the services related to Question.
 * @author shyam.patidar
 *
 */
public interface QuestionService {
	/**
	 * This method of service will return the list of all the questions.
	 * @return List<Question>
	 */
	public List<Question> listAllQuestion();
	/**
	 * This method of service  will return the list of specific category of questions.
	 * @param category
	 * @return List<Question>
	 */
	public List<Question> listAllQuestion(int category);
	/**
	 * This method of service  will approve or reject the question request.
	 * its will return positive integer if successfully action complete and return 0 if fail.
	 * @param status
	 * @param quetionId
	 * @return {@link Integer}
	 */
	public int changeQuestionStatus(int status,int quetionId);
	/**
	 * This method of service  will send the notification to the appropriate user after his question is approved or rejected by Admin.
	 * its will return true notification sent successfully
	 * @return {@link Boolean}
	 */
	public boolean updateNotification();
}
