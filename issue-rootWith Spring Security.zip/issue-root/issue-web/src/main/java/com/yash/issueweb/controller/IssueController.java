package com.yash.issueweb.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.core.userdetails.UsernameNotFoundException;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.bind.annotation.SessionAttribute;

import com.yash.issuecore.domain.Issue;
import com.yash.issuecore.domain.User;
import com.yash.issuecore.service.IssueService;

@RestController
@RequestMapping("/issues")
public class IssueController {
	@Autowired
	private IssueService issueService;

	@RequestMapping(value = "/list", method = RequestMethod.GET)
	public List<Issue> listAllIssues(@SessionAttribute User userInSession) {
		if(userInSession.getRoleid()==1){
		return issueService.listAllIssues();
		}else{
			throw new UsernameNotFoundException("User do not have the Authority ");
		}
	}

	@RequestMapping(value = "/listUserIssue/{id}", method = RequestMethod.GET)
	public List<Issue> listIssuesById(@PathVariable("id") int userid) {
		return issueService.listAllIssuesByUserId(userid);
	}

	@RequestMapping(value = "/addIssue", method = RequestMethod.POST)
	public String addNewIssue(@SessionAttribute User userInSession, @RequestBody Issue issue) {
		if (userInSession.getRoleid() == 1) {
			int status = issueService.addNewIssue(issue);
			if (status > 0) {
				return "Added";
			} else {
				return "Not Added";
			}
		} else
			throw new UsernameNotFoundException("User do not have the Authority ");
	}

	@RequestMapping(value = "/update", method = RequestMethod.PUT)
	public String updateIssue(@RequestBody Issue issue) {
		int status = issueService.updateAnExistingIssue(issue);
		if (status > 0) {
			return "Updated";
		} else {
			throw new UsernameNotFoundException("User do not have the Authority ");
		}
	}

	@RequestMapping(value = "/issues/{id}/issue/{status}", method = RequestMethod.PUT)
	public String updateIssueStatus(@PathVariable int id, @PathVariable int status) {
		int state = issueService.updateStatusByIssueId(id, status);
		if (state > 0) {
			return "Updated";
		} else {
			return "Not Updated";
		}
	}
}
