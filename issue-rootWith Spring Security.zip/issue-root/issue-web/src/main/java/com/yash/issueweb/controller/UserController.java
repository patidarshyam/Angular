package com.yash.issueweb.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.core.userdetails.UsernameNotFoundException;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.bind.annotation.SessionAttribute;

import com.yash.issuecore.domain.User;
import com.yash.issuecore.service.UserService;

@RestController
@RequestMapping("/users")
//@PreAuthorize("hasRole('ADMIN')")
public class UserController {
	@Autowired
	private UserService userService;

	@RequestMapping(value = "/list", method = RequestMethod.GET)
	public List<User> listAllUsers(@SessionAttribute User userInSession) {
		if (userInSession.getRoleid() == 1)
			return userService.listAllUsers();
		else
			throw new UsernameNotFoundException("User do not have Authority");
	}

	

	@RequestMapping(value = "/update", method = RequestMethod.PUT)
	public String updateUserDetails(@RequestBody User user,@SessionAttribute User userInSession) {
		System.out.println("Update Called");
		if(userInSession.getStatusid() == 1){
		int status = userService.updateUserDetails(user);
		if (status > 0)
			return "User Details Updated";
		else
			return "User Details Not Updated";
		}else{
			throw new UsernameNotFoundException("User do not have the Authority ");
		}
	}

}
