package com.yash.issuecore.service;

import java.util.List;

import com.yash.issuecore.domain.Issue;

public interface IssueService {
	
	public List<Issue> listAllIssues();
	
	public List<Issue> listAllIssuesByUserId(int userid);
	
	public int addNewIssue(Issue issue);
	
	public int updateAnExistingIssue(Issue issue);
	
	public int updateStatusByIssueId(int id,int status);
}
