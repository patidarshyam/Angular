package com.yash.issuecore.rowmapper;

import java.sql.ResultSet;
import java.sql.SQLException;

import org.springframework.jdbc.core.RowMapper;

import com.yash.issuecore.domain.User;

public class UserRowMapper implements RowMapper<User> {

	public User mapRow(ResultSet rs, int rowNum) throws SQLException {
		User user = new User();
		user.setId(rs.getInt("id"));
		user.setFirstName(rs.getString("firstName"));
		user.setLastName(rs.getString("lastName"));
		user.setLoginName(rs.getString("loginName"));
		user.setRoleid(rs.getInt("roleid"));
		user.setStatusid(rs.getInt("statusid"));
		user.setEmail(rs.getString("email"));
		return user;
	}

}
