package com.yash.issuecore.serviceimpl;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.yash.issuecore.dao.IssueDAO;
import com.yash.issuecore.domain.Issue;
import com.yash.issuecore.service.IssueService;

@Service
public class IssueServiceImpl implements IssueService {
	@Autowired
	private IssueDAO issueDAO;

	public List<Issue> listAllIssues() {
		return issueDAO.list();
	}

	public List<Issue> listAllIssuesByUserId(int userid) {
		return issueDAO.listById(userid);
	}

	public int addNewIssue(Issue issue) {
		return issueDAO.insert(issue);
	}

	public int updateAnExistingIssue(Issue issue) {
		return issueDAO.update(issue);
	}

	public int updateStatusByIssueId(int id, int status) {
		return issueDAO.updateStatus(id, status);
	}

}
