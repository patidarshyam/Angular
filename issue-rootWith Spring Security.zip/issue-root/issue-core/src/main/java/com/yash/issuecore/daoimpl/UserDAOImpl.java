package com.yash.issuecore.daoimpl;

import java.util.List;

import javax.sql.DataSource;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.stereotype.Repository;

import com.yash.issuecore.dao.UserDAO;
import com.yash.issuecore.domain.User;
import com.yash.issuecore.rowmapper.UserRowMapper;
@Repository
public class UserDAOImpl implements UserDAO {

	private JdbcTemplate jdbcTemplate;

	@Autowired
	public void setDataSource(DataSource dataSource) {
		this.jdbcTemplate = new JdbcTemplate(dataSource);
	}
	
	public int insert(User user) {
		String sql="INSERT INTO users(firstName,lastName,email,loginName,password) VALUES(?,?,?,?,?)";
		Object[] params={
				user.getFirstName(),
				user.getLastName(),
				user.getEmail(),
				user.getLoginName(),
				user.getPassword()
		};
		return jdbcTemplate.update(sql,params);
	}

	public int update(User user) {
		String sql="UPDATE users SET firstName=?,lastName=?,email=? WHERE id=?";
		Object[] params={
				user.getFirstName(),
				user.getLastName(),
				user.getEmail(),
				user.getId()
		};
		return jdbcTemplate.update(sql,params);
	}

	public List<User> list() {
		String sql="SELECT * FROM users";
		return jdbcTemplate.query(sql, new UserRowMapper());
	}

	public User getByLoginName(String loginName) {
		String sql="SELECT * FROM users WHERE loginName=?";
		return jdbcTemplate.queryForObject(sql, new UserRowMapper(),loginName);
	}

	public List<String> getUserRoles(String loginName) {
		User user=getByLoginName(loginName);
		String sql="SELECT role FROM user_roles WHERE id="+user.getRoleid();
		return jdbcTemplate.queryForList(sql, String.class);
	}
	
	
}
