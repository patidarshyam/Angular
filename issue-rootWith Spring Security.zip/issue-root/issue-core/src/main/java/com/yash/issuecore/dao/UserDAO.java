package com.yash.issuecore.dao;

import java.util.List;

import com.yash.issuecore.domain.User;

public interface UserDAO {
	
	public int insert(User user);
	
	public int update(User user);
	
	public List<User> list();
	
	public User getByLoginName(String loginName);
	
	public List<String> getUserRoles(String loginName);

}
