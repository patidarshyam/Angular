import { NgModule, ModuleWithProviders } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';

import { LoginComponent } from './logincomponent/logincomponent.component';
import { DashboardComponent } from './dashboard/dashboard.component';
import { Component, Input } from '@angular/core';
const appRoutes: Routes = [
  {
    path: '',
    redirectTo: '/login',
    pathMatch: 'full'
  },
  {
    path: 'login',
    component: LoginComponent
  },
  
  {
    path: 'dashboard',
    component: DashboardComponent
  }
];

@NgModule({
  exports: [RouterModule], imports: [RouterModule.forRoot(appRoutes)]
})
export class routing {
  @Input() user: LoginComponent;
}

