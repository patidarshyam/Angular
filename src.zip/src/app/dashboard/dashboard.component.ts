import { Component, OnInit, Input } from '@angular/core';
import { LoginComponent } from '../logincomponent/logincomponent.component';
import { Router, ActivatedRoute } from '@angular/router';  
import {Http} from '@angular/http'
@Component({
  selector: 'app-dashboard',
  templateUrl: './dashboard.component.html',
  styleUrls: ['./dashboard.component.css']
})
export class DashboardComponent implements OnInit {

  user;
  public constructor(private route: ActivatedRoute, private router:Router,private http:Http) {
    this.route.queryParams.subscribe(params => {
        this.user=params["user"];
    });
    if(this.user == null){
      router.navigate(["/login"])
    }
}

  ngOnInit() {
  }

  logout() {
    let url = 'http://localhost:4200';
    location.href=url;
  }

}
