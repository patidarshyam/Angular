export class User{
    firstname:String;
    lastname:String;
    email:String;
    loginname:String;
    password:String;
}