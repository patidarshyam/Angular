import { Component } from '@angular/core';
import { BreadcrumbDefinition, BreadcrumbService } from 'xng-breadcrumb';


@Component({
  selector: 'app-root',
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.scss']
})
export class AppComponent {
  title = 'breadcrumb-demo';
 }
