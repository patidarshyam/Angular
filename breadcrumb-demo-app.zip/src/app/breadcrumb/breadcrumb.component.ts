
import { Component, OnInit } from '@angular/core';
import { ActivatedRoute, Router, NavigationEnd } from '@angular/router';
import { BreadcrumbService } from '../../app/breadcrumb.service';


@Component({
  selector: 'app-breadcrumb',
  templateUrl: './breadcrumb.component.html',
  styleUrls: ['./breadcrumb.component.scss']
})
export class BreadcrumbComponent implements OnInit {

  breadcrumbs: any[] = [];

  ngOnInit(): void {

  }

  constructor(
    private router: Router,
    private route: ActivatedRoute,
    private breadcrumbService: BreadcrumbService // Inject BreadcrumbService here
  ) {
    this.router.events.subscribe(event => {
      if (event instanceof NavigationEnd) {
        this.breadcrumbs = this.breadcrumbService.buildBreadcrumbs(this.route.root); // Call the BreadcrumbService here
      }
    });
  }
  // constructor(
  //   private router: Router,
  //   private route: ActivatedRoute
  // ) {
  //   this.router.events.subscribe(event => {
  //     if (event instanceof NavigationEnd) {
  //       this.breadcrumbs = this.buildBreadcrumbs(this.route.root);
  //     }
  //   });
  // }

  // buildBreadcrumbs(route: ActivatedRoute, url: string = '', breadcrumbs: any[] = []): any[] {
  //   const label = route.routeConfig && route.routeConfig.data ? route.routeConfig.data['breadcrumb'] : 'Home';
  //   const path = route.routeConfig ? route.routeConfig.path : '';
  //   const nextUrl = `${url}${path}/`;


  //   const breadcrumb = {
  //     label,
  //     url: nextUrl
  //   };

  //   const newBreadcrumbs = [...breadcrumbs, breadcrumb];

  //   if (route.firstChild) {
  //     return this.buildBreadcrumbs(route.firstChild, nextUrl, newBreadcrumbs);
  //   }

  //   return newBreadcrumbs;
  
  // }


}
