import { Injectable, NgModule } from '@angular/core';
import { RouterModule, Routes, ActivatedRoute } from '@angular/router';
import { HomeComponent } from './home/home.component';
import { AboutComponent } from './about/about.component';
import { AboutChildComponent } from './about-child/about-child.component';
import { ContactComponent } from './contact/contact.component';

import { MatIconModule } from '@angular/material/icon';


const routes: Routes = [
  {
    path: '',
    component: HomeComponent,
    data: {
      breadcrumb: 'Home',
      title: 'Home'
    }
  },
  {
    path: 'home',
    component: HomeComponent,
    data: {
      breadcrumb: 'Home',
      title: 'Home'
    }
  },
  {
    path: 'about',
    component: AboutComponent,
    data: {
      breadcrumb: 'About Us',
      title: 'Home'
    },
    children: [
      {
        path: 'child',
        component: AboutChildComponent,
        data: {
          breadcrumb: 'Child'
        }
      }
    ]
  },
  {
    path: 'contact',
    component: ContactComponent,
    data: {
      breadcrumb: 'Contact Us'
    }
  }
];


@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule]
})
export class AppRoutingModule { }
