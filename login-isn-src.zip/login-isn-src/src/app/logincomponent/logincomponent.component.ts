import { Component, OnInit, Output } from '@angular/core';
import {Observable}  from 'rxjs/Observable';
import {LoginService} from '../login.service';
import { Router, NavigationExtras } from '@angular/router';  

@Component({
  selector: 'app-logincomponent',
  templateUrl: './logincomponent.component.html',
  styleUrls: ['./logincomponent.component.css']
})
export class LoginComponent implements OnInit {

  user:object;
  loggedin:boolean;
  username: string;
  password: string;
	constructor (private loginService: LoginService,private router:Router) {
   
  }
  
  onSubmit() {
  	this.loginService.sendCredential(this.username, this.password).subscribe(
      
      res => {

        this.user=JSON.parse(JSON.parse(JSON.stringify(res))._body);
        console.log(this.user);
        this.loggedin=!this.loggedin;
        let navigationExtras: NavigationExtras = {
          queryParams: {
              "user": this.user
          }
      };
        this.router.navigate(["/dashboard"], navigationExtras);
      },
      err => console.log("not logged in successfully")
    );
  }

  ngOnInit() {}

}