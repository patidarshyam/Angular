import { Component, OnInit } from '@angular/core';
import { UserService } from '../../user.service';
import { Router } from '@angular/router';

@Component({
  selector: 'app-user-list',
  templateUrl: './user-list.component.html',
  styleUrls: ['./user-list.component.css']
})
export class UserListComponent implements OnInit {
  user:object;
  userList:object[];
  constructor(private userService:UserService, private router:Router) { }
  getUsersList(){
    this.userService.getUsers().subscribe(
      res =>{
          this.user=JSON.parse(localStorage.getItem('userLoggedIn'));
          console.log(this.user);
          this.userList=JSON.parse(JSON.parse(JSON.stringify(res))._body);
          console.log(this.userList);
      },
      error =>{console.log("User Is Not Authorized to List");
      }
    )
  }
  ngOnInit() {
    this.getUsersList();
  }

  changeStatus(userid:number){
    this.userService.changeUserStatus(userid).subscribe();
  }
}
