import { Component, OnInit } from '@angular/core';
import {Observable}  from 'rxjs/Observable';
import { LoginService } from '../login.service';
import { Router } from '@angular/router';

@Component({
  selector: 'app-login',
  templateUrl: './login.component.html',
  styleUrls: ['./login.component.css']
})
export class LoginComponent implements OnInit {
  loggedIn:boolean;
  loginName:string;
  password:string;
  user:object={
    email:'',
    firstName:'',
    id:'',
    lastName:'',
    loginName:'',
    password:'',
    roleid:'',
    statusid:''};
  constructor(private loginService:LoginService,private router:Router) { 
    if(localStorage.getItem('LoggedIn') == '' || localStorage.getItem('LoggedIn') == null) {
      this.loggedIn = false;
    } else {
      this.loggedIn = true;
    }
  }
  onSubmit(){
    this.loginService.checkCredential(this.loginName,this.password).subscribe(
      res => {
        this.user=JSON.parse(JSON.parse(JSON.stringify(res))._body);
        console.log(this.user['roleid']);
        this.loggedIn=true;
        localStorage.setItem('LoggedIn', 'true');
        localStorage.setItem('userLoggedIn',JSON.stringify(this.user));
        if(this.user['roleid']==1){
        this.router.navigate(["/adminDashboard"]);
        }else{
        this.router.navigate(["/dashboard"]);
        }
      },
      err => console.log("UserName does not Exist")
    );
  }

  ngOnInit() {
  }

}
