import { Injectable } from '@angular/core';
import {Http, Headers} from '@angular/http';
import {Observable}     from 'rxjs/Observable';

@Injectable()
export class IssueService {

  constructor(private http:Http) { }

  getIssues(){
    let url = "http://localhost:8080/issue-web/issues/list";
    return this.http.get(url, { withCredentials: true });
  }

  getIssuesById(userId:number){
    let url = "http://localhost:8080/issue-web/issues/listUserIssue/"+userId;
    return this.http.get(url, { withCredentials: true });
  }

  addIssue(issue:object){

  }
}
