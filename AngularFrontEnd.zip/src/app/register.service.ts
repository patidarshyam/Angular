import { Injectable } from '@angular/core';
import {Http, Headers} from '@angular/http';
import {Observable}     from 'rxjs/Observable';

@Injectable()
export class RegisterService {

  constructor(private http:Http) { }
  registerUser(firstName:string,lastName:string,email:string,loginName:string,password:string){
    var user={"firstName":firstName, "lastName":lastName, "email":email, "loginName":loginName, "password":password}
  let url = 'http://localhost:8080/issue-web/register';
  let params = user;
  let headers = new Headers(
  { 'Content-Type': 'application/json' });
  return this.http.post(url, params, {headers: headers, withCredentials : true});
  }
}
