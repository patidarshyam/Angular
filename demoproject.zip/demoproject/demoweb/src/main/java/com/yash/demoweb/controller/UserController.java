package com.yash.demoweb.controller;

import javax.servlet.http.HttpServletRequest;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;

import com.yash.democore.dao.UserDAO;
import com.yash.democore.model.User;



@RestController
public class UserController {

	@Autowired
	UserDAO userDAO;
	
	@RequestMapping(value = "/login", method = RequestMethod.POST)
	public User login(@RequestBody User user, HttpServletRequest request) {

		User userloggedin = userDAO.login(user.getName(), user.getPassword());
		if (userloggedin != null) {
			request.getSession().setAttribute("userinsession", userloggedin);
			return userloggedin;
		} else
			return null;
	}
	
	
}
