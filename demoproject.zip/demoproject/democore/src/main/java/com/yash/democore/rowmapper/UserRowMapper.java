package com.yash.democore.rowmapper;

import java.sql.ResultSet;
import java.sql.SQLException;

import org.springframework.jdbc.core.RowMapper;

import com.yash.democore.model.User;

public class UserRowMapper implements RowMapper<User> {

	public User mapRow(ResultSet rs, int arg1) throws SQLException {
		User user =new User();
		user.setId(rs.getLong("id"));
		user.setName(rs.getString("loginname"));
		user.setContact(rs.getString("contact"));
		user.setPassword(rs.getString("password"));
		return user;
	}

}
