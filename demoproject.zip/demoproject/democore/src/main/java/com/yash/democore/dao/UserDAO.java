package com.yash.democore.dao;

import java.util.List;

import com.yash.democore.model.User;


public interface UserDAO  {

	public User login(String loginname,String password);
	public void register(User user);
	public void delete(int id);
	public void update(User newUser);
	public List<User> listUsers(int id);
}
